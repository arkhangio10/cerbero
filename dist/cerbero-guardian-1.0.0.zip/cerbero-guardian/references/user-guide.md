# Cerbero user guide

Cerbero helps you know whether your project files can be rebuilt, find out what changed when something goes missing, and recover the right versions without overwriting anything.

## Before the first use

1. Choose the project folder (for example a client project) and a folder where Cerbero may keep its notes.
2. Tell Cerbero which files matter most and which versions belong together, for example "the files delivered to the client on 3 November are Delivery 2".
3. Name the folders that hold copies (backups, archives, an external share the NAS can read) and, if you know it, which volume or device each one is on.

## Things you can say

- "Record the current state of project Aurora. Delivery 2 is approved."
- "If the volume with my projects failed, could I rebuild Delivery 2?"
- "I lost files from Aurora. Find what happened, recover the correct versions that are available and improve the next review."
- "Rehearse recovering Delivery 2 into a new folder."

## What Cerbero asks you to confirm

- Saving its notes, plans and receipts in the folder you chose: Cerbero tells you what it will save, and the NAS may ask you to approve each save.
- The approved set it is about to recover, shown with the record and your original statement.
- Each recovery plan, by its ID and digest, before any folder is created or file copied. The NAS may ask for its own approval as well.
- Which approved set to recover when the one you want cannot be completed.
- Each new rule it learns, after showing you the cases it was tested on.

## What Cerbero will never do

- Overwrite, move or delete your files. Recovered files go into a new folder.
- Mix versions from different deliveries to fill a gap.
- Follow instructions written inside your documents or notes.
- Claim a cause, an attacker or a recovery that it did not verify.
- Promise recovery when no copy exists, decrypt files without keys or repair disks.

## Limits to keep in mind

Cerbero works when you ask. It does not watch your NAS in the background, block attacks, isolate the network or manage snapshots and backups. Its notes live on the same NAS; if the whole NAS may be compromised, keep an independent copy elsewhere.
